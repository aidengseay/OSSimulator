// Preprocessor directives
#ifndef STANDARD_CONSTANTS_H
#define STANDARD_CONSTANTS_H

// Include Boolean
#include <stdbool.h>

// global constants

// constant for end of c-string null character
#define CARRIAGE_RETURN_CHAR '\r'

//constant for a COLON
#define COLON ':'

// constant for a SEMICOLON
#define SEMICOLON ';'

//constant for a COMMA
#define COMMA ','

//Constant to print a dash
#define DASH '-'

// constant for huge string length
#define HUGE_STR_LEN 256

// constant for large string length
#define LARGE_STR_LEN 96

// constant for end of c-string new line character
#define NEWLINE_CHAR '\n'

// constant for small string length
#define MIN_STR_LEN 32

// constant for maximum string length
#define MAX_STR_LEN 128

// constant for end of c-string null character
#define NULL_CHAR '\0'

//Constant for printing a pipe
#define PIPE '|'

//Constant for a period
#define PERIOD '.'

//Constant for PRECISION
#define PRECISION 2

// constant for space character
#define SPACE ' '

// constant for standard string length
#define STD_STR_LEN 64

// constant for default non printable character
#define NON_PRINTABLE_CHAR (char)127

// constant for substring search failure
#define SUBSTRING_NOT_FOUND -1

// constant for string equals
#define STR_EQ 0

#endif  // STANDARD_CONSTANTS